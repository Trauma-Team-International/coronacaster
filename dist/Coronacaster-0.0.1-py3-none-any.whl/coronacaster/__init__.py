from .data import get_data_from_eu
from .plots import plot_country
from .fit import fit

del data, plots